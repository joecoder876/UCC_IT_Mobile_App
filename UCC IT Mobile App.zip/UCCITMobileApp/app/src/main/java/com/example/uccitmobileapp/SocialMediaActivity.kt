package com.example.uccitmobileapp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class SocialMediaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_social_media)

        findViewById<Button>(R.id.btnFacebook).setOnClickListener {
            openSocialMedia("http://facebook.com/uccjamaica")
        }

        findViewById<Button>(R.id.btnTwitter).setOnClickListener {
            openSocialMedia("http://twitter.com/uccjamaica")
        }

        findViewById<Button>(R.id.btnInstagram).setOnClickListener {
            openSocialMedia("https://www.instagram.com/uccjamaica")
        }
    }

    private fun openSocialMedia(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open link", Toast.LENGTH_SHORT).show()
        }
    }
}